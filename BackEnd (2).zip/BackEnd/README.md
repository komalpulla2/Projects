# Torque Reduction

Torque reduction web api uses python Fast api template.
