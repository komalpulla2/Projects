from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:komal1968@localhost/DMQL_H1BDATABASEPROJECT'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = "somethingunique"
db = SQLAlchemy(app)

class soc(db.Model):
    soc_id = db.Column(db.Integer, primary_key=True)
    soc_code = db.Column(db.String, nullable=False)
    soc_name = db.Column(db.String, nullable=False)

    def __init__(self, soc_code, soc_name):
        self.soc_code = soc_code
        self.soc_name = soc_name

@app.route('/')
def index():
    socs = soc.query.order_by(soc.soc_id.desc()).limit(100).all()
    return render_template('index.html', socs=socs)

@app.route('/soc/add/', methods=['POST'])
def insert_soc():
    if request.method == "POST":
        soc_instance = soc(
            soc_code=request.form.get('soc_code'),
            soc_name=request.form.get('soc_name')
        )
        db.session.add(soc_instance)
        db.session.commit()
        flash("SOC added successfully")
        return redirect(url_for('index'))

@app.route('/soc/update/', methods=['POST'])
def soc_update():
    if request.method == "POST":
        soc_data = soc.query.get(request.form.get('soc_id'))
        soc_data.soc_code = request.form['soc_code']
        soc_data.soc_name = request.form['soc_name']

        db.session.commit()
        flash("SOC is updated")
        return redirect(url_for('index'))

@app.route('/soc/delete/<soc_id>/', methods=['GET', 'POST'])
def soc_delete(soc_id):
    soc_data = soc.query.get(soc_id)
    db.session.delete(soc_data)
    db.session.commit()
    flash("SOC is deleted")
    return redirect(url_for('index'))


if __name__ == "__main__":
    app.run(debug=True)