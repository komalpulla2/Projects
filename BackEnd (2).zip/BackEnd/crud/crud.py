
from sqlalchemy.orm import Session, session
from models.models import  ProplanS52rfeli
from models.models import ProplanS52rpber
from models.models import ProplanS52rfeliB
from models.models import  DataQuality
from typing import Optional

from sqlalchemy import text

from models.models import GridView

def readplant_data(db:Session):
  data = db.query(ProplanS52rfeli.WERK).distinct().filter(ProplanS52rfeli.PLANUNGSHOHEIT == 'TOP').all()
  return data

def readbuilding_data(db:Session,plant_id:str):
  data = db.query(ProplanS52rfeliB).filter(ProplanS52rfeliB.PLANUNGSHOHEIT == 'TOP',ProplanS52rfeliB.WERK.contains(plant_id)).all()
  print(data)
  return data

def readplannings_data(db:Session,plant_id:str,planning_scope:str):
  n_id = plant_id.lstrip('0')
  data = db.query(ProplanS52rpber).order_by(ProplanS52rpber.GUELTIG_AB.desc()).filter(ProplanS52rpber.WERK == n_id,
                                                                                      ProplanS52rpber.BENENNUNG.contains(planning_scope)).all()
  print(data)
  return data
def readplanning_data(db:Session,plant_id:str):
  n_id = plant_id.lstrip('0')
  data = db.query(ProplanS52rpber).order_by(ProplanS52rpber.GUELTIG_AB.desc()).filter(ProplanS52rpber.WERK == n_id,
                                                                                      ).all()
  return data
def read_dataquality(db:Session):
  data = db.query(DataQuality).all()
  for i in data:
    d = i.__dict__
    d["Percent_valid_torque"] = d["Percent_valid_torque"]+"%"
    d["Percent_avo_found"] = d["Percent_avo_found"]+"%"
  print(data)
  return data


def readgridnew_data(db:Session,plant_id:Optional[str] = None,planning_id:Optional[str] = None,screw_head: Optional[str] = None,building_id: Optional[str] = None,screw_class:Optional[str]= None,confusion_flag:Optional[str]=None):
  if (plant_id == None) and (planning_id == None) and  (screw_head  ==   None) and (building_id  ==   None) and (screw_class == None) and (confusion_flag == None) :
    data = db.query(GridView).limit(50).all()
    return data
  else:
    print(plant_id,planning_id,screw_head,building_id,screw_class)
    list_param=[str(plant_id),str(planning_id),str(screw_head),str(building_id),str(confusion_flag)]
    list_sql=["PLANT == ","PLANUNGSBEREICHID ==","SWAntrieb ==","BUILDING == ","confusion_flag =="]
    list_param=["'" + item + "'" for item in list_param]
    list_concat = list(sub1 + sub2 for sub1, sub2 in zip(list_sql,list_param))
    result=[x for x in list_concat if not 'None' in x]

    filter_sql=""

    if(len(result)!=0):
      filter_sql=" AND ".join(result)

    if(screw_class!= None):

      screw_class=screw_class.split(",")
      screw_class=["'" + item + "'" for item in screw_class]
      screw_class=",".join(screw_class)

      if(filter_sql != ""):
        filter_class=" AND " + "Screw_Class IN (" +screw_class + ")"
        filter_sql+=filter_class
      else:
        filter_sql+="Screw_Class IN (" +screw_class + ")"

    print(filter_sql)
    data = db.query(GridView).filter(text(filter_sql)).limit(1000).all()
    return data
