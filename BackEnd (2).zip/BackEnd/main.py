import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from pydantic import BaseSettings

from routes.routes import proplan
import  sys

tags_metadata = [
    {
        "name": "Torque-Reduction",
        "description": "Torque-Api Details.",
    }]
class Settings(BaseSettings):
    openapi_url: str = "/openapi.json"
settings = Settings()


app = FastAPI(openapi_url=settings.openapi_url, openapi_tags=tags_metadata)
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(title="TORQUE",
                                 version="2.5.0",
                                 description="Torque Reduction API",
                                 routes=app.routes,
                                 )
    openapi_schema["info"]["x-logo"] = {
        "url": "mbrdi.png"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi



sys.setrecursionlimit(10**8)

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)




app.include_router(proplan)

# Custom Api
if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
