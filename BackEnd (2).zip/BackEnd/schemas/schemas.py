from typing import List

from pydantic import BaseModel

from typing import Optional

class Plant(BaseModel):
    WERK: str


class Building(BaseModel):
    WERK: str
    FERTIGUNGSLINIEID : int
    BENENNUNG :str

class PlanningScope(BaseModel):
    PLANUNGSBEREICHID:int
    BENENNUNG: str
    WERK: str

class All(BaseModel):
    WERK: str
    FERTIGUNGSLINIEID : int
    BENENNUNG: str
    PLANUNGSBEREICHID:int

class GridSchema(BaseModel):
    BR: Optional[str]
    AA: Optional[str]
    RASTER : Optional[str]
    POSV : Optional[str]
    POS : Optional[str]
    PARTNUMBER : Optional[str]
    DESCRIPTION : Optional[str]
    SCREW_HEAD : Optional[str]
    Torque : Optional[str]
    STATION: Optional[str]
    PCS : Optional[str]
    PLANT : Optional[str]
    BUILDING : Optional[str]
    PLANUNGSBEREICHID : Optional[str]
    B_LEVEL : Optional[str]
    LINE :Optional[str]
    confusion_flag :Optional[str]
    column_count :Optional[int]

    class Config:
        orm_mode = True