import sqlalchemy
from sqlalchemy import Table, Column, Integer, String,BigInteger,Float,DECIMAL
from database.database import Base


class ProplanS52rfeli(Base):
    __tablename__= "s52rfeli"
    __table_args__ = {'extend_existing': True}
    FERTIGUNGSLINIEID = Column(Integer,primary_key=True)
    WERK= Column(String)
    PLANUNGSHOHEIT= Column(String)

class ProplanS52rfeliB(Base):
    __tablename__ = "s52rfeli"
    __table_args__ = {'extend_existing': True}
    FERTIGUNGSLINIEID = Column(Integer,primary_key=True)
    BENENNUNG  =Column(String)
    WERK= Column(String)
    PLANUNGSHOHEIT= Column(String)

class ProplanS52rfeliM(Base):
    __tablename__ = "s52rfeli"
    __table_args__ = {'extend_existing': True}

    FERTIGUNGSLINIEID = Column(Integer,primary_key=True)
    BENENNUNG  =Column(String)
    WERK= Column(String)
    PFKZ = Column(String)
    KAPAZITAET = Column(Integer)
    LETZTEAENDERUNG= Column(String)
    LETZTERBEARBEITER= Column(String)
    PLANUNGSHOHEIT= Column(String)
    MIGRATIONS_STATUS= Column(String)

class ProplanS52rpber(Base):
    __tablename__= "s52rpber"
    PLANUNGSBEREICHID= Column(Integer,primary_key=True)
    WERK =Column(String)
    BENENNUNG = Column(String)
    GUELTIG_AB = Column(String)


class DataQuality(Base):
    __tablename__ = "data_quality"
    No_Of_Entries = Column(String,primary_key = True)
    Percent_valid_torque = Column(String)
    Percent_avo_found = Column(String)


class Brtp(Base):
    __tablename__ = "brtp"
    brtp_br = Column(String,primary_key = True)
    brtp_ras =  Column(String)
    brtp_aa = Column(String)
    brtp_pv = Column(String)
    brtp_pose = Column(String)
    brtp_teil =Column(String)
    brtp_mg =Column(DECIMAL)

class Bctx(Base):
    __tablename__ = "bctx"
    bctx_br = Column(String)
    bctx_txt = Column(String,primary_key = True)
    bctx_ras = Column(String)
    bctx_pose = Column(String)
    bctx_pv = Column(String)

class S52rpbav(Base):
    __tablename__ = "s52rpbav"
    PLANUNGSBEREICHID  = Column(Integer,primary_key=True)
    ORT_ALLGEMEIN=Column(String)
    ZZ_BENENNUNG_DE=Column(String)
class GridView(Base):
    __tablename__ = "filtered_data"
    BR = Column(String,primary_key = True)
    AA =  Column(String,primary_key = True)
    RASTER = Column(String,primary_key = True)
    POSV = Column(String,primary_key = True)
    POS = Column(String,primary_key = True)
    PARTNUMBER =Column(String,primary_key = True)
    DESCRIPTION =Column(String,primary_key = True)
    SWAntrieb =Column(String,primary_key = True)
    Torque =Column(String,primary_key = True)
    STATION =Column(String,primary_key = True)
    PCS =Column(DECIMAL,primary_key = True)
    PLANT =Column(String,primary_key = True)
    BUILDING =Column(String,primary_key = True)
    PLANUNGSBEREICHID =Column(String,primary_key = True)
    B_LEVEL =Column(String,primary_key = True)
    LINE =Column(String,primary_key = True)
    Screw_Class =Column(String,primary_key = True)
    confusion_flag =Column(String,primary_key = True)
    column_count = Column(Integer,primary_key = True)