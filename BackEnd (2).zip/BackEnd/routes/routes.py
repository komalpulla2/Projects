from typing import List, Optional

from fastapi import APIRouter
from fastapi.middleware.cors import CORSMiddleware

import schemas.schemas
from crud import crud
from database import  database
from models import models
from sqlalchemy.orm import Session, session
from fastapi.param_functions import Depends
from typing import Optional

proplan = APIRouter()

def get_db():
    db = None
    try:
        db = database.Sessionlocal()
        yield db
    finally:
        db.close()


@proplan.get("/plant/")
async def read_plantdata(db: Session = Depends(get_db)):
    data = crud.readplant_data(db)
    return data

@proplan.get("/dataQuality/")
async def read_plantdata(db: Session = Depends(get_db)):
    data = crud.read_dataquality(db)
    return data

@proplan.get("/buildinglist/")
async def read_buildingdata(plant_id: str,db: Session = Depends(get_db)):
    data = crud.readbuilding_data(db,plant_id)
    return data
@proplan.get("/searchplanningdata/")
async def read_planningsdata(plant_id: str,planning_scope: str,db: Session = Depends(get_db)):
    data = crud.readplannings_data(db,plant_id,planning_scope)
    return data
@proplan.get("/planningdata/")
async def read_planningdata(plant_id: str,db: Session = Depends(get_db)):
    data = crud.readplanning_data(db,plant_id)
    return data
@proplan.get("/griddata/")
async def read_newgriddata(plant_id: Optional[str] = None,planning_id: Optional[str] = None,screw_head : Optional[str] = None,building_id : Optional[str] = None,screw_class :Optional[str] = None ,confusion_flag:Optional[str] = None,db: Session = Depends(get_db)):
    data = crud.readgridnew_data(db,plant_id, planning_id,screw_head,building_id,screw_class,confusion_flag)
    return data

